-- =========================================================
-- DATABASE: bank_sampah
-- Dibuat berdasarkan ERD: users, sampah, transaksi, tarik_saldo
-- =========================================================

CREATE DATABASE IF NOT EXISTS bank_sampah;
USE bank_sampah;

-- =========================================================
-- 1. TABEL USERS (tabel induk)
-- =========================================================
CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    saldo DECIMAL(15,2) DEFAULT 0,
    role ENUM('admin','user') DEFAULT 'user'
);

-- =========================================================
-- 2. TABEL SAMPAH
-- =========================================================
CREATE TABLE sampah (
    id_sampah INT AUTO_INCREMENT PRIMARY KEY,
    jenis_sampah VARCHAR(100) NOT NULL,
    harga DECIMAL(15,2) NOT NULL,
    stok_kg DECIMAL(10,2) DEFAULT 0
);

-- =========================================================
-- 3. TABEL TRANSAKSI
-- relasi: users (1) - transaksi (N), sampah (1) - transaksi (N)
-- =========================================================
CREATE TABLE transaksi (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_sampah INT NOT NULL,
    tipe VARCHAR(50) NOT NULL,
    berat_kg DECIMAL(10,2) NOT NULL,
    total_rp DECIMAL(15,2) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transaksi_user FOREIGN KEY (id_user) REFERENCES users(id_user)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_transaksi_sampah FOREIGN KEY (id_sampah) REFERENCES sampah(id_sampah)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- =========================================================
-- 4. TABEL TARIK_SALDO
-- relasi: users (1) - tarik_saldo (N)
-- =========================================================
CREATE TABLE tarik_saldo (
    id_tarik INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    nominal DECIMAL(15,2) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending','sukses','ditolak') DEFAULT 'pending',
    CONSTRAINT fk_tarik_user FOREIGN KEY (id_user) REFERENCES users(id_user)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- =========================================================
-- CONTOH DATA (opsional, boleh dihapus kalau tidak perlu)
-- =========================================================
INSERT INTO users (nama, username, password, saldo, role) VALUES
('Admin Utama', 'admin', 'admin123', 0, 'admin'),
('Budi Santoso', 'budi', 'budi123', 50000, 'user');

INSERT INTO sampah (jenis_sampah, harga, stok_kg) VALUES
('Plastik Botol', 3000, 0),
('Kertas Kardus', 2000, 0),
('Kaleng Aluminium', 8000, 0),
('Besi Bekas', 3500, 0);

INSERT INTO transaksi (id_user, id_sampah, tipe, berat_kg, total_rp) VALUES
(2, 1, 'setor', 5.00, 15000);

INSERT INTO tarik_saldo (id_user, nominal, status) VALUES
(2, 10000, 'pending');
